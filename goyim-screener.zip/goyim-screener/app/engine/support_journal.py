"""Forward test of the support signals on real alerts (the live ones can't be backtested).

Every touch alert's support check is saved on the day it's sent. Later, the daily bars show whether the
line held (no close more than 2% through it within 10 trading days). The Strategy Test page then shows,
for each signal, how often the line held when the signal was on vs off.
"""
from datetime import datetime

from . import store, support

FILE = "support_checks.json"
MAX_KEEP = 2000


def add(ticker, day, chk, side="above", source="scan"):
    if not chk or not chk.get("signals"):
        return
    rows = store.load(FILE, []) or []
    if any(r["ticker"] == ticker and r["date"] == day and r["line"] == chk["line"] for r in rows):
        return
    rows.append({"ticker": ticker, "date": day, "line": chk["line"], "level": round(chk["level"], 4), "side": side,
                 "source": source, "signals": {k: v["ok"] for k, v in chk["signals"].items()},
                 "saved": datetime.now().isoformat(timespec="seconds")})
    store.save(FILE, rows[-MAX_KEEP:])


def _outcome(row, bars):
    import numpy as np
    import pandas as pd

    kind, n = row["line"].split()
    n = int(n)
    c = bars["close"]
    line = c.rolling(n).mean() if kind == "SMA" else c.ewm(span=n, adjust=False).mean()
    idx = c.index.tz_convert(None) if c.index.tz is not None else c.index
    pos = int(np.searchsorted(idx.normalize().values, np.datetime64(pd.Timestamp(row["date"])), side="right")) - 1
    if pos < 0 or pos >= len(c):
        return None, None
    held = support._held(c.values.astype(float), line.values.astype(float), pos, row.get("side", "above"), support.DEFAULTS)
    k = min(len(c) - 1, pos + 20)
    ret = (c.iloc[k] / c.iloc[pos] - 1) * 100 if k > pos else None
    return held, ret


def evaluate(get_bars, limit=600):
    rows = (store.load(FILE, []) or [])[-limit:]
    out, errors = [], []
    for r in rows:
        try:
            held, ret = _outcome(r, get_bars(r["ticker"]))
        except Exception as e:
            errors.append(f"{r['ticker']}: {e}")
            held, ret = None, None
        out.append({**r, "held": held, "ret": None if ret is None else round(float(ret), 2)})
    done = [x for x in out if x["held"] is not None]
    keys = [k for k, _, _ in support.ALL]
    table = support.compare(out, keys)
    return {"summary": {"checks": len(out), "finished": len(done),
                        "held_rate": round(100 * sum(1 for x in done if x["held"]) / len(done), 1) if done else None},
            "signals": table, "rows": list(reversed(out))[:80], "errors": errors[:5]}
