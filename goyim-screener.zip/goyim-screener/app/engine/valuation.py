"""Valuation scores: how cheap or expensive each sector (and gold, oil, bonds, the dollar, breadth) is
compared with its OWN history. Score -10 (extremely overvalued) ... 0 (normal) ... +10 (extremely undervalued).

Sectors (from SEC filings + Public prices), each compared with the last ~10 years of quarter-ends:
  P/E        sum of members' market caps / sum of trailing-12-month net income   (lower = cheaper)
  P/S        market caps / trailing revenue                                        (lower = cheaper)
  FCF yield  trailing free cash flow / market caps                                 (higher = cheaper)
  plus two price checks on the sector ETF:
  vs SPY     the ETF/SPY price ratio vs its own range                              (low = cheap vs the market)
  stretch    % above/below the 200-day average vs its usual range                  (far below = washed out)
Members: the biggest US companies in each SEC industry group (up to 25 per sector).

Gold, silver, oil, bonds (TLT), the dollar: no earnings, so price-based: where price sits in its 10-year
range, how stretched it is from the 200-day average, and its ratio to SPY.
Breadth: % of stocks above their 200-day average (contrarian: very low = washed out = positive).

Each piece becomes a number from -1 (most expensive in its history) to +1 (cheapest) using its percentile;
the weighted average x 10 is the score. Percentiles say "unusual for this asset", not "will go up".
"""
import math
from datetime import date, datetime, timedelta

import numpy as np

from . import store

SECTOR_ETF = {
    "Technology": "XLK", "Communication": "XLC", "Consumer discretionary": "XLY", "Financials": "XLF",
    "Industrials": "XLI", "Health care": "XLV", "Consumer staples": "XLP", "Energy and mining": "XLE",
    "Materials": "XLB", "Utilities": "XLU", "Real estate": "XLRE",
}
ASSETS = [("GLD", "Gold"), ("SLV", "Silver"), ("USO", "Oil"), ("TLT", "Long-term bonds (TLT)"),
          ("IEF", "7-10 yr bonds (IEF)"), ("UUP", "US dollar")]
HISTORY_FILE = "valuation_history.json"
SECTOR_WEIGHTS = {"pe": 0.30, "ps": 0.15, "fcfy": 0.20, "rel": 0.15, "stretch": 0.20}
ASSET_WEIGHTS = {"range": 0.35, "stretch": 0.35, "rel": 0.30}


def _r(x, d=2):
    if x is None:
        return None
    x = float(x)
    return None if math.isnan(x) or math.isinf(x) else round(x, d)


def label(score):
    if score is None:
        return "No data"
    if score >= 7:
        return "Extremely undervalued"
    if score >= 3:
        return "Undervalued"
    if score > -3:
        return "Fair value"
    if score > -7:
        return "Overvalued"
    return "Extremely overvalued"


def percentile(hist, now):
    h = [x for x in hist if x is not None and not (isinstance(x, float) and math.isnan(x))]
    if len(h) < 8 or now is None:
        return None
    return sum(1 for x in h if x < now) / len(h) * 100


def _qkey(end):
    d = date.fromisoformat(end) - timedelta(days=15)
    return f"{d.year}-Q{(d.month - 1) // 3 + 1}"


# ----------------------------------------------------------------------
# sector fundamentals history (slow: built weekly in the background)
# ----------------------------------------------------------------------
def pick_members(engine, per_sector=25, log=print):
    """{sector: [tickers]} using the screener table (or the universe list + SEC company info)."""
    db = store.load("screener_db.json", None)
    rows = []
    if db and db.get("rows"):
        rows = [(r["ticker"], r.get("sector"), r.get("market_cap") or 0) for r in db["rows"]]
    else:
        uni = None
        for name in ("universe_5B.json", "universe_2B.json", "universe_1B.json"):
            uni = store.load(name, None)
            if uni:
                break
        if not uni:
            raise RuntimeError("Needs the stock list: open Screener and press Update data once")
        info = store.load("company_info.json", {})
        caps = uni.get("market_caps", {})
        for t in sorted(caps, key=lambda x: -caps[x])[:600]:
            sec = (info.get(t) or {}).get("sic_sector")
            if sec is None:
                try:
                    ci, _ = engine.call_first("company_info", t)
                    info[t] = ci
                    sec = ci.get("sic_sector")
                except Exception:
                    continue
            rows.append((t, sec, caps[t]))
        store.save("company_info.json", info)
    out = {}
    for t, sec, cap in sorted(rows, key=lambda r: -r[2]):
        if sec in SECTOR_ETF and len(out.setdefault(sec, [])) < per_sector:
            out[sec].append(t)
    return out


def company_points(history, bars):
    """Per quarter-end: market cap and trailing-12-month revenue / net income / free cash flow."""
    import pandas as pd

    if not history or bars is None or not len(bars):
        return {}, None
    closes = bars["close"]
    idx = closes.index.tz_convert(None).normalize() if closes.index.tz is not None else closes.index
    closes = pd.Series(closes.values, index=idx)
    m, qs = history["metrics"], history["quarters"]
    pts = {}
    latest = None
    for i in range(3, len(qs)):
        def ttm(k):
            xs = m.get(k, [])[i - 3:i + 1]
            return sum(xs) if len(xs) == 4 and all(x is not None for x in xs) else None
        rev, ni, fcf, sh = ttm("revenue"), ttm("net_income"), ttm("fcf"), m["shares"][i]
        px = closes[:pd.Timestamp(qs[i])]
        if not len(px) or not sh or rev is None:
            continue
        price = float(px.iloc[-1])
        pts[_qkey(qs[i])] = {"end": qs[i], "mcap": price * sh, "rev": rev, "ni": ni, "fcf": fcf}
        latest = {"shares": sh, "rev": rev, "ni": ni, "fcf": fcf, "end": qs[i]}
    return pts, latest


def aggregate(points_by_company):
    """Sum members per quarter -> [{key, pe, ps, fcfy, n}] (only companies with that quarter)."""
    keys = sorted({k for pts in points_by_company.values() for k in pts})
    out = []
    for k in keys:
        rows = [pts[k] for pts in points_by_company.values() if k in pts]
        if len(rows) < 3:
            continue
        mc = sum(r["mcap"] for r in rows)
        rev = sum(r["rev"] for r in rows)
        ni_rows = [r for r in rows if r["ni"] is not None]
        fcf_rows = [r for r in rows if r["fcf"] is not None]
        ni = sum(r["ni"] for r in ni_rows)
        fcf = sum(r["fcf"] for r in fcf_rows)
        mc_ni = sum(r["mcap"] for r in ni_rows)
        mc_f = sum(r["mcap"] for r in fcf_rows)
        out.append({"key": k, "n": len(rows), "pe": _r(mc_ni / ni, 2) if ni > 0 else None,
                    "ps": _r(mc / rev, 3) if rev > 0 else None, "fcfy": _r(fcf / mc_f * 100, 3) if mc_f else None})
    return out


def build_history(engine, status=None, should_stop=lambda: False, per_sector=25, log=print):
    from .scanner import Context

    st = status if status is not None else {}
    st.update(stage="Picking the biggest companies in each sector")
    members = pick_members(engine, per_sector, log)
    todo = [(sec, t) for sec, ts in members.items() for t in ts]
    st.update(stage="Reading filings and price history", total=len(todo), done=0)
    pts, latest = {}, {}
    prof = {"id": "valuation", "fast": 150, "slow": 200}
    for i, (sec, t) in enumerate(todo):
        if should_stop():
            break
        st.update(done=i, current=t)
        try:
            ctx = Context(engine, t, prof, {"values": {}, "fetched": set()})
            h = ctx.get("history")
            try:
                bars = ctx.get("bars_10y")
            except Exception:
                bars = ctx.get("bars")
            p, last = company_points(h, bars)
            if p:
                pts.setdefault(sec, {})[t] = p
                latest.setdefault(sec, {})[t] = last
        except Exception as e:
            log(f"Valuation: {t} skipped ({e})")
    sectors = {}
    for sec in members:
        series = aggregate(pts.get(sec, {}))
        sectors[sec] = {"etf": SECTOR_ETF[sec], "members": list(pts.get(sec, {}).keys()), "history": series,
                        "latest": latest.get(sec, {})}
    allpts = {f"{s}:{t}": p for s, d in pts.items() for t, p in d.items()}
    hist = {"built": datetime.now().isoformat(timespec="seconds"), "sectors": sectors,
            "market": {"history": aggregate(allpts),
                       "latest": {f"{s}:{t}": v for s, d in latest.items() for t, v in d.items()}}}
    store.save(HISTORY_FILE, hist)
    st.update(stage="Done", done=len(todo))
    return hist


# ----------------------------------------------------------------------
# scores (fast: run with the daily scan, uses the saved history + today's prices)
# ----------------------------------------------------------------------
def _now_fundamentals(latest, prices):
    mc = rev = ni = fcf = mc_ni = mc_f = 0.0
    n = 0
    for key, v in (latest or {}).items():
        t = key.split(":")[-1]
        px = prices.get(t)
        if not px or not v.get("shares") or v.get("rev") is None:
            continue
        cap = px * v["shares"]
        n += 1
        mc += cap
        rev += v["rev"]
        if v.get("ni") is not None:
            ni += v["ni"]
            mc_ni += cap
        if v.get("fcf") is not None:
            fcf += v["fcf"]
            mc_f += cap
    if n < 3:
        return None
    return {"n": n, "pe": mc_ni / ni if ni > 0 else None, "ps": mc / rev if rev > 0 else None,
            "fcfy": fcf / mc_f * 100 if mc_f else None}


def _price_parts(bars10, bars5, spy10):
    """range: where price sits in its full history; stretch: % from the 200-day average vs history; rel: vs SPY."""
    import pandas as pd

    out = {}
    if bars10 is not None and len(bars10):
        w = bars10["close"].resample("W-FRI").last().dropna()
        if len(w) > 60:
            out["range"] = {"now": float(w.iloc[-1]), "pct": percentile(w.values.tolist()[:-1], float(w.iloc[-1])),
                            "lo": float(w.min()), "hi": float(w.max()), "years": _r(len(w) / 52, 1)}
        if spy10 is not None and len(spy10):
            s = spy10["close"].resample("W-FRI").last().dropna()
            j = pd.concat([w.rename("a"), s.rename("s")], axis=1, join="inner").dropna()
            if len(j) > 60:
                ratio = (j["a"] / j["s"]).values
                out["rel"] = {"now": float(ratio[-1]), "pct": percentile(ratio[:-1].tolist(), float(ratio[-1])),
                              "chg_1y": _r((ratio[-1] / ratio[-53] - 1) * 100) if len(ratio) > 53 else None}
    if bars5 is not None and len(bars5) > 260:
        c = bars5["close"]
        dev = (c / c.rolling(200).mean() - 1).dropna() * 100
        if len(dev) > 60:
            out["stretch"] = {"now": float(dev.iloc[-1]), "pct": percentile(dev.values[:-1].tolist(), float(dev.iloc[-1])),
                              "median": _r(float(dev.median()))}
    return out


def _cheap(pct, higher_is_cheaper=False):
    if pct is None:
        return None
    s = 1 - 2 * pct / 100
    return -s if higher_is_cheaper else s


def _score(parts, weights):
    tot = wsum = 0.0
    for k, w in weights.items():
        v = parts.get(k, {}).get("cheap") if parts.get(k) else None
        if v is None:
            continue
        tot += w * v
        wsum += w
    return _r(10 * tot / wsum, 1) if wsum >= 0.3 else None


def snapshot(engine, hist=None, breadth_hist=None, log=print):
    """Scores for every sector, the market, gold/silver/oil/bonds/dollar and breadth."""
    from .scanner import Context

    hist = hist if hist is not None else store.load(HISTORY_FILE, None)
    prof = {"id": "valuation", "fast": 150, "slow": 200}

    def bars(t, long=False):
        try:
            return Context(engine, t, prof, engine.shared_cache(t)).get("bars_10y" if long else "bars")
        except Exception:
            if long:
                return bars(t)
            return None

    spy10 = bars("SPY", True)
    rows = []
    # members' prices right now (one batch request)
    prices = {}
    if hist:
        tick = sorted({k.split(":")[-1] for k in (hist.get("market", {}).get("latest") or {})})
        try:
            q, _ = engine.call_first("quotes", tick)
            prices = {t: v["last"] for t, v in q.items() if v.get("last")}
        except Exception as e:
            log(f"Valuation quotes failed: {e}")

    def fundamental_parts(entry, latest):
        parts = {}
        nowf = _now_fundamentals(latest, prices)
        h = entry.get("history") or []
        for k, inv in (("pe", False), ("ps", False), ("fcfy", True)):
            series = [x.get(k) for x in h]
            now = nowf.get(k) if nowf else None
            pct = percentile(series, now)
            vals = [x for x in series if x is not None]
            parts[k] = {"now": _r(now, 2), "pct": _r(pct, 1), "median": _r(float(np.median(vals)), 2) if vals else None,
                        "lo": _r(min(vals), 2) if vals else None, "hi": _r(max(vals), 2) if vals else None,
                        "cheap": _cheap(pct, inv), "points": len(vals)}
        return parts, (nowf or {}).get("n")

    def add(kind, name, ticker, parts, weights, extra=None):
        for k, v in parts.items():
            if v and "cheap" not in v:
                v["cheap"] = _cheap(v.get("pct"))
            if v:
                v["pct"] = _r(v.get("pct"), 1)
                v["cheap"] = _r(v.get("cheap"), 3)
                for f in ("now", "lo", "hi"):
                    if f in v:
                        v[f] = _r(v[f], 3)
        sc = _score(parts, weights)
        rows.append({"kind": kind, "name": name, "ticker": ticker, "score": sc, "label": label(sc), "parts": parts,
                     **(extra or {})})

    # sectors
    for sec, etf in SECTOR_ETF.items():
        parts, n = ({}, None)
        entry = (hist or {}).get("sectors", {}).get(sec)
        if entry:
            parts, n = fundamental_parts(entry, {f"{sec}:{t}": v for t, v in (entry.get("latest") or {}).items()})
            parts["pe_hist"] = None
        pp = _price_parts(bars(etf, True), bars(etf), spy10)
        parts["rel"] = pp.get("rel")
        parts["stretch"] = pp.get("stretch")
        parts.pop("pe_hist", None)
        hist_pe = [{"key": x["key"], "pe": x.get("pe")} for x in (entry or {}).get("history", [])]
        add("sector", sec, etf, parts, SECTOR_WEIGHTS, {"members": n, "pe_history": hist_pe[-40:]})

    # whole market (all sector members together) + SPY price checks
    if hist and hist.get("market"):
        parts, n = fundamental_parts(hist["market"], hist["market"].get("latest"))
        pp = _price_parts(spy10, bars("SPY"), None)
        parts["stretch"] = pp.get("stretch")
        add("market", "US market (all sectors)", "SPY", parts, {"pe": 0.35, "ps": 0.2, "fcfy": 0.25, "stretch": 0.2},
            {"members": n, "pe_history": [{"key": x["key"], "pe": x.get("pe")} for x in hist["market"]["history"]][-40:]})

    # gold, silver, oil, bonds, dollar
    for t, name in ASSETS:
        pp = _price_parts(bars(t, True), bars(t), spy10)
        add("asset", name, t, {"range": pp.get("range"), "stretch": pp.get("stretch"), "rel": pp.get("rel")}, ASSET_WEIGHTS)

    # breadth (contrarian): % of stocks above their 200-day average, and equal-weight vs cap-weight
    parts = {}
    if breadth_hist and len(breadth_hist) > 100:
        now = breadth_hist[-1]
        parts["above200"] = {"now": now, "pct": percentile(breadth_hist[:-1], now),
                             "median": _r(float(np.median(breadth_hist)), 1)}
    else:
        db = store.load("screener_db.json", None)
        if db and db.get("rows"):
            rows_ = [r for r in db["rows"] if r.get("ema_200") and r.get("price")]
            if rows_:
                now = 100 * sum(1 for r in rows_ if r["price"] > r["ema_200"]) / len(rows_)
                # no history yet: compare with a typical 20%-80% band
                parts["above200"] = {"now": _r(now, 1), "pct": max(0.0, min(100.0, (now - 20) / 60 * 100)),
                                     "note": "vs a typical 20–80% range (run the Strategy Test once for real history)"}
    rsp = _price_parts(bars("RSP", True), bars("RSP"), spy10)
    if rsp.get("rel"):
        parts["equal_vs_cap"] = rsp["rel"]
    add("breadth", "Market breadth", "RSP", parts, {"above200": 0.6, "equal_vs_cap": 0.4})

    sectors = sorted([r for r in rows if r["kind"] == "sector" and r["score"] is not None], key=lambda r: -r["score"])
    return {"as_of": datetime.now().isoformat(timespec="seconds"), "history_built": (hist or {}).get("built"),
            "rows": rows, "cheapest": [r["name"] for r in sectors[:3]], "richest": [r["name"] for r in sectors[-3:][::-1]]}


def breadth_history(ds):
    """% of stocks above their 200-day EMA on each day, from the Strategy Test's cached prices."""
    if not ds or "bars" not in ds:
        return None
    from .strategy_bt import _frames, _ma

    try:
        cal, fr, tickers = _frames(ds)
        c = fr["c"]
        e200 = _ma(c, 200, "EMA")
        seen = np.cumsum(~np.isnan(c), axis=0) >= 220
        with np.errstate(invalid="ignore"):
            above = (c > e200) & seen
        cnt = seen.sum(axis=1)
        out = [float(100 * a / n) for a, n in zip(above.sum(axis=1), cnt) if n >= 50]
        return out or None
    except Exception:
        return None


def telegram_lines(snap, top=3):
    if not snap or not snap.get("rows"):
        return []
    rows = snap["rows"]
    sec = sorted([r for r in rows if r["kind"] == "sector" and r["score"] is not None], key=lambda r: -r["score"])
    f = lambda r: f"{r['name']} {r['score']:+.0f}"
    lines = ["📊 <b>Valuation</b> (+10 very cheap · −10 very expensive vs own history)"]
    if sec:
        lines.append("Cheapest: " + ", ".join(f(r) for r in sec[:top]))
        lines.append("Richest: " + ", ".join(f(r) for r in sec[-top:][::-1]))
    other = [r for r in rows if r["kind"] in ("market", "asset", "breadth") and r["score"] is not None
             and r["ticker"] in ("SPY", "GLD", "USO", "TLT", "RSP")]
    if other:
        names = {"SPY": "Market", "GLD": "Gold", "USO": "Oil", "TLT": "Bonds", "RSP": "Breadth"}
        lines.append(" · ".join(f"{names[r['ticker']]} {r['score']:+.0f}" for r in other))
    return lines if len(lines) > 1 else []
