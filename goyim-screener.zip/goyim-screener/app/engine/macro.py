"""Macro environment + theme rotation: is this a market for swing longs, and is money leaving this stock's trade?

MACRO SCORE  -10 (risk-off) .. +10 (risk-on), from daily data (each day uses only data up to that day):
  vix_level   VIX < 15 calm (+1) · 15-20 (+0.5) · 20-25 (0) · 25-30 (-0.5) · > 30 panic (-1)
  vix_spike   VIX vs its 20-day average: > 1.25x fear spike (-1) · > 1.10x (-0.5) · < 0.90x fear fading (+0.5)
  trend       SPY above its 50 and 200 EMA (+1) · above the 200 only (0) · below the 200 (-1)
  drawdown    SPY within 5% of its 1-year high (+0.5) · 5-10% (0) · more than 10% off (-1)
  breadth     equal-weight RSP vs SPY over a month: broad rally (+0.5) · narrow, few stocks carrying it (-0.5)
  credit      high-yield HYG vs Treasuries IEF over a month: credit calm (+0.5) · credit stress (-1)
  Regime: +3 or more = Risk-on (good for swings) · -2 to +3 = Mixed (be picky) · below -2 = Risk-off (skip new swings)

THEME ROTATION  every stock is matched to the ETF it actually trades with (highest correlation of daily returns
over ~6 months among sector + industry ETFs: WDC -> SMH semis, not just XLK). That theme is "at risk" when
2 or more of these are true:
  weakening   the theme ETF is in the Weakening or Lagging quadrant vs SPY (losing relative strength)
  outflow     it lagged SPY by more than 2% over the last 10 days (money leaving right now)
  crowded     its valuation score is -3 or worse (stretched vs its own history)
That's the WDC case: the AI trade was overvalued AND weakening, so a pullback to the EMA kept getting sold.
"""
import math
import time

import numpy as np

MACRO_TICKERS = ["VIX", "SPY", "RSP", "HYG", "IEF"]
THEMES = [
    ("XLK", "Technology"), ("XLC", "Communication"), ("XLY", "Consumer discretionary"), ("XLF", "Financials"),
    ("XLI", "Industrials"), ("XLV", "Health care"), ("XLP", "Consumer staples"), ("XLE", "Energy"),
    ("XLB", "Materials"), ("XLU", "Utilities"), ("XLRE", "Real estate"),
    ("SMH", "Semiconductors / AI"), ("IGV", "Software"), ("XBI", "Biotech"), ("KRE", "Regional banks"),
    ("XHB", "Homebuilders"), ("ITA", "Aerospace & defense"), ("XOP", "Oil & gas producers"), ("GDX", "Gold miners"),
    ("XRT", "Retail"), ("IYT", "Transports"), ("TAN", "Solar"), ("CIBR", "Cybersecurity"),
]
THEME_NAME = dict(THEMES)
WEIGHTS = {"vix_level": 0.25, "vix_spike": 0.15, "trend": 0.25, "drawdown": 0.10, "breadth": 0.10, "credit": 0.15}
RISK_ON, RISK_OFF = 3.0, -2.0
_CACHE = {}


def _r(x, d=2):
    if x is None:
        return None
    x = float(x)
    return None if math.isnan(x) or math.isinf(x) else round(x, d)


def regime(score):
    if score is None:
        return "Unknown"
    return "Risk-on" if score >= RISK_ON else "Risk-off" if score < RISK_OFF else "Mixed"


REGIME_TEXT = {"Risk-on": "good for swing longs", "Mixed": "be picky: best setups only, smaller size",
               "Risk-off": "skip new swing longs", "Unknown": "not enough data"}


# ----------------------------------------------------------------------
# macro score, every day
# ----------------------------------------------------------------------
def score_history(closes):
    """closes: {"VIX": Series, "SPY": Series, "RSP", "HYG", "IEF"} (daily closes). -> DataFrame with each
    component (-1..+1), "score" (-10..+10) and the raw readings, on SPY's dates. Past data only on each day."""
    import pandas as pd

    spy = closes["SPY"]
    df = pd.DataFrame(index=spy.index)
    df["spy"] = spy
    for k in ("VIX", "RSP", "HYG", "IEF"):
        s = closes.get(k)
        df[k.lower()] = s.reindex(spy.index).ffill() if s is not None and len(s) else np.nan
    comp = pd.DataFrame(index=df.index)
    v = df["vix"]
    comp["vix_level"] = np.select([v < 15, v < 20, v < 25, v < 30, v >= 30], [1, 0.5, 0, -0.5, -1], default=np.nan)
    comp.loc[v.isna(), "vix_level"] = np.nan
    spike = v / v.rolling(20, min_periods=15).mean()
    comp["vix_spike"] = np.select([spike > 1.25, spike > 1.10, spike < 0.90], [-1, -0.5, 0.5], default=0.0)
    comp.loc[spike.isna(), "vix_spike"] = np.nan
    e50, e200 = spy.ewm(span=50, adjust=False).mean(), spy.ewm(span=200, adjust=False).mean()
    comp["trend"] = np.where((spy > e50) & (spy > e200), 1.0, np.where(spy > e200, 0.0, -1.0))
    comp.loc[spy.index[:200], "trend"] = np.nan
    dd = spy / spy.rolling(252, min_periods=120).max() - 1
    comp["drawdown"] = np.select([dd > -0.05, dd > -0.10], [0.5, 0.0], default=-1.0)
    comp.loc[dd.isna(), "drawdown"] = np.nan
    br = (df["rsp"] / spy).pct_change(21)
    comp["breadth"] = np.select([br > 0.01, br < -0.02], [0.5, -0.5], default=0.0)
    comp.loc[br.isna(), "breadth"] = np.nan
    cr = (df["hyg"] / df["ief"]).pct_change(21)
    comp["credit"] = np.select([cr > 0.005, cr < -0.01], [0.5, -1.0], default=0.0)
    comp.loc[cr.isna(), "credit"] = np.nan
    w = pd.Series(WEIGHTS)
    have = comp.notna()
    num = (comp.fillna(0) * w).sum(axis=1)
    den = (have * w).sum(axis=1)
    out = comp.copy()
    out["score"] = np.where(den >= 0.5, 10 * num / den.replace(0, np.nan), np.nan)
    out["vix"] = v
    out["vix_pct_1y"] = v.rolling(252, min_periods=120).apply(lambda a: 100 * (a[:-1] < a[-1]).mean(), raw=True)
    out["spy_dd"] = dd * 100
    return out


def fear_label(vix, pct):
    if vix is None:
        return "unknown"
    if vix >= 30:
        return "panic"
    if vix >= 25 or (pct is not None and pct >= 85):
        return "fearful"
    if vix >= 20 or (pct is not None and pct >= 65):
        return "nervous"
    if vix < 14 and (pct is None or pct < 20):
        return "complacent"
    return "calm"


# ----------------------------------------------------------------------
# theme rotation
# ----------------------------------------------------------------------
def theme_for(stock_close, theme_closes, window=126, end=None):
    """The theme ETF the stock moves with most (correlation of daily returns over `window` days ending at `end`)."""
    import pandas as pd

    r = stock_close.pct_change()
    best, best_c = None, -2.0
    for etf, s in theme_closes.items():
        j = pd.concat([r.rename("a"), s.pct_change().rename("b")], axis=1, join="inner").dropna()
        if end is not None:
            j = j[j.index <= end]
        j = j.iloc[-window:]
        if len(j) < 40:
            continue
        c = j["a"].corr(j["b"])
        if c is not None and not math.isnan(c) and c > best_c:
            best, best_c = etf, c
    return best, (None if best is None else round(best_c, 2))


def theme_history(etf_close, spy_close):
    """Daily theme state (past data only): DataFrame with quadrant (0 Lead, 1 Weak, 2 Lag, 3 Improving),
    val_score, rel10 (% vs SPY over 10 days), and the three flags + risk count."""
    import pandas as pd

    from .rotation import quadrant_history
    from .sector_filter import price_score_history

    idx = spy_close.index
    q = quadrant_history(etf_close, spy_close).reindex(idx)
    val = price_score_history(etf_close, spy_close).reindex(idx)
    e = etf_close.reindex(idx).ffill()
    rel10 = ((e / e.shift(10)) / (spy_close / spy_close.shift(10)) - 1) * 100
    df = pd.DataFrame({"quadrant": q, "val_score": val, "rel10": rel10}, index=idx)
    df["weakening"] = df["quadrant"].isin([1, 2])
    df["outflow"] = df["rel10"] < -2.0
    df["crowded"] = df["val_score"] <= -3.0
    df["risk"] = df[["weakening", "outflow", "crowded"]].sum(axis=1)
    return df


def theme_state_text(row, etf):
    from .rotation import QUADRANTS
    q = row.get("quadrant")
    qn = QUADRANTS[int(q)] if q is not None and not (isinstance(q, float) and math.isnan(q)) and q >= 0 else "?"
    bits = [f"{etf} ({THEME_NAME.get(etf, etf)}) {qn}"]
    if row.get("val_score") is not None and not math.isnan(row["val_score"]):
        bits.append(f"valuation {row['val_score']:+.1f}")
    if row.get("rel10") is not None and not math.isnan(row["rel10"]):
        bits.append(f"{row['rel10']:+.1f}% vs SPY in 10d")
    flags = [k for k in ("weakening", "outflow", "crowded") if row.get(k)]
    return " · ".join(bits), flags


# ----------------------------------------------------------------------
# live: today's snapshot (cached 30 min)
# ----------------------------------------------------------------------
def _closes(engine, tickers):
    from .scanner import Context

    out = {}
    for t in tickers:
        try:
            df = Context(engine, t, {"id": "macro", "fast": 150, "slow": 200}, engine.shared_cache(t)).get("bars")
            if df is not None and len(df):
                c = df["close"].astype(float)
                c.index = c.index.tz_convert(None).normalize() if c.index.tz is not None else c.index.normalize()
                out[t] = c[~c.index.duplicated(keep="last")]
        except Exception as e:
            engine.log(f"Macro data {t}: {e}")
    return out


def snapshot(engine, max_age=1800):
    """{"score", "regime", "text", "components", "vix", "fear", "themes": {etf: {...}}, "into": [...], "out_of": [...]}"""
    from .rotation import QUADRANTS

    hit = _CACHE.get(id(engine))
    if hit and time.time() - hit[0] < max_age:
        return hit[1]
    cl = _closes(engine, MACRO_TICKERS + [e for e, _ in THEMES])
    if "SPY" not in cl:
        raise RuntimeError("No SPY prices for the macro check")
    hist = score_history(cl)
    last = hist.iloc[-1]
    comps = {k: _r(last.get(k), 2) for k in WEIGHTS}
    vix, vpct = _r(last.get("vix")), _r(last.get("vix_pct_1y"), 0)
    themes = {}
    for etf, name in THEMES:
        if etf not in cl:
            continue
        th = theme_history(cl[etf], cl["SPY"]).iloc[-1]
        text, flags = theme_state_text(th, etf)
        q = th["quadrant"]
        themes[etf] = {"name": name, "quadrant": QUADRANTS[int(q)] if not math.isnan(q) and q >= 0 else None,
                       "val_score": _r(th["val_score"], 1), "rel10": _r(th["rel10"], 1), "flags": flags,
                       "risk": int(th["risk"]), "text": text}
    # where money is heading: improving/leading, not crowded, gaining vs SPY lately
    score_t = lambda t: (t["rel10"] or 0) + (2 if t["quadrant"] in ("Improving", "Leading") else -2) + (t["val_score"] or 0) * 0.3
    ranked = sorted(themes.items(), key=lambda kv: -score_t(kv[1]))
    into = [e for e, t in ranked if t["risk"] == 0 and t["quadrant"] in ("Improving", "Leading")][:4]
    out_of = [e for e, t in ranked[::-1] if t["risk"] >= 2][:4]
    sc = _r(last.get("score"), 1)
    snap = {"score": sc, "regime": regime(sc), "text": REGIME_TEXT[regime(sc)], "components": comps,
            "vix": vix, "vix_pct_1y": vpct, "fear": fear_label(vix, vpct), "spy_dd": _r(last.get("spy_dd"), 1),
            "themes": themes, "into": into, "out_of": out_of,
            "history": [{"date": d.strftime("%Y-%m-%d"), "score": _r(s, 1)} for d, s in hist["score"].dropna().iloc[-260::5].items()]}
    _CACHE[id(engine)] = (time.time(), snap)
    return snap


def stock_theme(engine, ticker, bars=None):
    """(etf, corr) for one stock today; cached for the day in the company-info file."""
    from datetime import date

    from . import store

    info = store.load("company_info.json", {}) or {}
    rec = info.get(ticker) or {}
    if rec.get("theme") and rec.get("theme_day") == date.today().isoformat()[:7]:      # refresh monthly
        return rec["theme"], rec.get("theme_corr")
    if bars is None:
        cl = _closes(engine, [ticker])
        sc = cl.get(ticker)
    else:
        sc = bars["close"].astype(float)
        sc.index = sc.index.tz_convert(None).normalize() if sc.index.tz is not None else sc.index.normalize()
    if sc is None:
        return None, None
    th = _closes(engine, [e for e, _ in THEMES])
    etf, corr = theme_for(sc, th)
    if etf:
        info.setdefault(ticker, {}).update(theme=etf, theme_corr=corr, theme_day=date.today().isoformat()[:7])
        store.save("company_info.json", info)
    return etf, corr


def lines(snap):
    """Telegram header lines for the daily scan."""
    if not snap:
        return []
    c = snap["components"]
    emo = {"Risk-on": "🟢", "Mixed": "🟡", "Risk-off": "🔴"}.get(snap["regime"], "⚪")
    out = [f"{emo} <b>Macro: {snap['regime']}</b> ({snap['score']:+.1f}) — {snap['text']}" if snap["score"] is not None
           else "⚪ Macro: not enough data",
           f"VIX {snap['vix']} ({snap['fear']}, {snap['vix_pct_1y']:.0f}th pct of the year) · SPY {snap['spy_dd']:+.1f}% from its high"
           if snap.get("vix") is not None and snap.get("vix_pct_1y") is not None else
           f"SPY {snap['spy_dd']:+.1f}% from its high" if snap.get("spy_dd") is not None else ""]
    if snap.get("out_of"):
        out.append("💸 Money leaving: " + ", ".join(f"{e} ({snap['themes'][e]['name']})" for e in snap["out_of"]))
    if snap.get("into"):
        out.append("💰 Money moving into: " + ", ".join(f"{e} ({snap['themes'][e]['name']})" for e in snap["into"]))
    return [x for x in out if x]
