"""Sector rule: only alert stocks in leading sectors, or in undervalued sectors (pick one)."""
from engine.plugin_api import Param, Rule


class SectorFilter(Rule):
    """Rotation = the stock's sector ETF (XLK, XLF, XLE...) vs SPY, as on the Rotation page.
    Valuation = the sector's -10..+10 score, as on the Rotation page's Valuation tab."""
    id = "leading_sector"
    name = "Sector filter: leading or undervalued"
    group = "Market"
    description = ("Only alert when the stock's sector is Leading SPY (rotation) or Undervalued (valuation score "
                   "+3 or more). Pick which one below. Sector comes from the company's SEC industry code.")
    needs = ["sic_sector", "bars"]
    default_enabled = False

    def __init__(self):
        from engine.sector_filter import RULE_CHOICES
        self.params = [
            Param("allow", "Only sectors that are", "Leading only", kind="choice", choices=RULE_CHOICES),
            Param("unmapped", "Let through stocks with no sector ETF", False, kind="bool"),
        ]

    def check(self, ctx, p):
        from engine import sector_filter as sf
        k = sf.key(p["allow"])
        sec = sf.sector_of(ctx.engine, ctx.ticker, ctx)
        info = sf.live(ctx.engine, sec, want=(sf.kind(k),))
        ctx.set("sector", sec)
        if info["quadrant"]:
            ctx.set("sector_quadrant", info["quadrant"])
        if info["score"] is not None:
            ctx.set("sector_value", info["score"])
        if info["etf"] is None:
            return bool(p["unmapped"]), f"{sec or 'unknown sector'}: no sector ETF to check"
        ok = sf.passes(k, info["quadrant"], info["score"])
        if sf.kind(k) == "rotation":
            return ok, f"{sec} ({info['etf']}) is {info['quadrant'] or 'unknown'}"
        sc = info["score"]
        return ok, f"{sec} valuation {'n/a' if sc is None else f'{sc:+.1f}'} ({info['value'] or 'no data'})"
