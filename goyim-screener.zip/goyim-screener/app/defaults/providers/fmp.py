"""FMP (Financial Modeling Prep, financialmodelingprep.com): long daily price history for the Strategy Test.

Public's daily bars stop at 5 years. FMP's Premium plan has 30+ years of daily bars, so the Strategy Test can
replay 10, 15 or 20 years (the 2018 selloff, the 2020 crash, the 2022 bear market...). Only the Strategy Test
uses it, so charts and scans keep using Public and FMP calls go to backtests only.

Plans (check FMP's pricing page for current terms): Free = 250 calls/day; Starter = 5 years of history;
Premium = 30+ years and 750 calls/minute. A 1,000-stock universe needs ~1,000 calls per download.

API: https://financialmodelingprep.com/stable/historical-price-eod/full?symbol=AAPL&from=YYYY-MM-DD&apikey=...
(split-adjusted daily open/high/low/close/volume). Falls back to the older v3 endpoint if needed.
"""
import time
from datetime import date, timedelta

from engine.plugin_api import KeyField, Provider

STABLE = "https://financialmodelingprep.com/stable/historical-price-eod/full"
LEGACY = "https://financialmodelingprep.com/api/v3/historical-price-full/{sym}"
SYMBOL_MAP = {"VIX": "^VIX", "SPX": "^GSPC", "NDX": "^NDX", "RUT": "^RUT", "DJI": "^DJI"}


def _rows(data):
    """Accepts the stable list format or the legacy {"historical": [...]} format."""
    if isinstance(data, dict):
        if data.get("Error Message") or data.get("error"):
            raise RuntimeError(str(data.get("Error Message") or data.get("error"))[:200])
        data = data.get("historical") or data.get("data") or []
    return data if isinstance(data, list) else []


def to_frame(rows):
    import pandas as pd

    keep = [r for r in rows if r.get("date") and r.get("close") is not None]
    if not keep:
        return None
    df = pd.DataFrame({
        "open": [float(r.get("open") if r.get("open") is not None else r["close"]) for r in keep],
        "high": [float(r.get("high") if r.get("high") is not None else r["close"]) for r in keep],
        "low": [float(r.get("low") if r.get("low") is not None else r["close"]) for r in keep],
        "close": [float(r["close"]) for r in keep],
        "volume": [float(r.get("volume") or 0) for r in keep],
    }, index=pd.to_datetime([str(r["date"])[:10] for r in keep]))
    df = df[~df.index.duplicated(keep="last")].sort_index()
    return df


class FMP(Provider):
    name = "FMP (Financial Modeling Prep)"
    description = ("Long daily price history for the Strategy Test (Premium plan: 30+ years). "
                   "Only used when you pick FMP as the Strategy Test's price data.")
    key_fields = [KeyField("api_key", "API key", help="financialmodelingprep.com → Dashboard → API key")]
    supplies = []                  # not used by scans/charts; the Strategy Test calls daily_bars() directly
    optional = True
    priority = 60
    signup_url = "https://site.financialmodelingprep.com/developer/docs/pricing"

    def _get(self, url, params):
        import requests

        last = None
        for attempt in range(3):
            r = requests.get(url, params=dict(params, apikey=self.keys["api_key"]), timeout=40)
            if r.status_code == 200:
                return r.json()
            if r.status_code in (401, 402, 403):
                txt = r.text[:200]
                raise RuntimeError(f"FMP {r.status_code}: {txt or 'key not valid for this data'} "
                                   "(long history needs a plan that includes it, e.g. Premium)")
            if r.status_code == 429:                  # rate limit: wait and retry
                time.sleep(5 * (attempt + 1))
                last = "rate limit reached"
                continue
            last = f"HTTP {r.status_code}"
            time.sleep(1 + attempt)
        raise RuntimeError(f"FMP: {last}")

    def daily_bars(self, ticker, years=10):
        """Daily OHLCV DataFrame (oldest first) covering `years` years."""
        ok, msg = self.ready()
        if not ok:
            raise RuntimeError(f"FMP: {msg}")
        sym = SYMBOL_MAP.get(ticker.upper(), ticker.upper()).replace(".", "-")
        frm = (date.today() - timedelta(days=int(365.25 * years) + 10)).isoformat()
        try:
            rows = _rows(self._get(STABLE, {"symbol": sym, "from": frm}))
        except RuntimeError as e:
            if "FMP 4" in str(e):
                raise
            rows = []
        if not rows:                                   # older accounts / endpoints
            rows = _rows(self._get(LEGACY.format(sym=sym), {"from": frm}))
        return to_frame(rows)

    def fetch(self, ctx):
        """Used by 'Test' on the Data sources page: how many years of daily bars your plan returns."""
        df = self.daily_bars(ctx.ticker, years=30)
        if df is None or not len(df):
            return {}
        return {"fmp_daily_years": round((df.index[-1] - df.index[0]).days / 365.25, 1)}
